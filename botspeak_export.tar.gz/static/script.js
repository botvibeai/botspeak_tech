/**
 * BotSpeak Web Interface JavaScript
 * Handles all frontend interactions and API calls
 */

// Global state
let isLoading = false;
let dictionaryStats = null;
let examples = [];
let usageInfo = null;

// DOM Elements
const elements = {
    // Encoder elements
    inputText: null,
    encodedOutput: null,
    encodeBtn: null,
    clearInputBtn: null,
    copyEncodedBtn: null,
    useAsDecoderInputBtn: null,
    encodingStats: null,
    
    // Decoder elements
    inputCodes: null,
    decodedOutput: null,
    decodeBtn: null,
    clearCodesBtn: null,
    copyDecodedBtn: null,
    decodingStats: null,
    
    // Dictionary elements
    dictionarySearch: null,
    searchBtn: null,
    randomEntriesBtn: null,
    searchResults: null,
    
    // Other elements
    loadingModal: null,
    loadingText: null,
    examplesList: null
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    initializeElements();
    attachEventListeners();
    loadInitialData();
});

/**
 * Initialize DOM element references
 */
function initializeElements() {
    // Encoder elements
    elements.inputText = document.getElementById('inputText');
    elements.encodedOutput = document.getElementById('encodedOutput');
    elements.encodeBtn = document.getElementById('encodeBtn');
    elements.clearInputBtn = document.getElementById('clearInputBtn');
    elements.copyEncodedBtn = document.getElementById('copyEncodedBtn');
    elements.useAsDecoderInputBtn = document.getElementById('useAsDecoderInputBtn');
    elements.encodingStats = document.getElementById('encodingStats');
    
    // Decoder elements
    elements.inputCodes = document.getElementById('inputCodes');
    elements.decodedOutput = document.getElementById('decodedOutput');
    elements.decodeBtn = document.getElementById('decodeBtn');
    elements.clearCodesBtn = document.getElementById('clearCodesBtn');
    elements.copyDecodedBtn = document.getElementById('copyDecodedBtn');
    elements.decodingStats = document.getElementById('decodingStats');
    
    // Dictionary elements
    elements.dictionarySearch = document.getElementById('dictionarySearch');
    elements.searchBtn = document.getElementById('searchBtn');
    elements.randomEntriesBtn = document.getElementById('randomEntriesBtn');
    elements.searchResults = document.getElementById('searchResults');
    
    // Other elements
    elements.loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    elements.loadingText = document.getElementById('loadingText');
    elements.examplesList = document.getElementById('examplesList');
}

/**
 * Attach event listeners
 */
function attachEventListeners() {
    // Encoder events
    elements.encodeBtn.addEventListener('click', encodeText);
    elements.clearInputBtn.addEventListener('click', clearInput);
    elements.copyEncodedBtn.addEventListener('click', copyEncoded);
    elements.useAsDecoderInputBtn.addEventListener('click', useAsDecoderInput);
    // Removed auto-encode to prevent interrupting typing
    
    // Decoder events
    elements.decodeBtn.addEventListener('click', decodeText);
    elements.clearCodesBtn.addEventListener('click', clearCodes);
    elements.copyDecodedBtn.addEventListener('click', copyDecoded);
    // Removed auto-decode to prevent interrupting typing
    
    // Dictionary events
    elements.searchBtn.addEventListener('click', searchDictionary);
    elements.randomEntriesBtn.addEventListener('click', loadRandomEntries);
    elements.dictionarySearch.addEventListener('input', debounce(searchDictionary, 300));
    elements.dictionarySearch.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchDictionary();
        }
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', handleKeyboardShortcuts);
}

/**
 * Load initial data
 */
async function loadInitialData() {
    try {
        // Load dictionary stats
        await loadDictionaryStats();
        
        // Load examples
        await loadExamples();
        
        console.log('Initial data loaded successfully');
    } catch (error) {
        console.error('Error loading initial data:', error);
        showError('Failed to load initial data');
    }
}

/**
 * Encode text function
 */
async function encodeText() {
    const text = elements.inputText.value.trim();
    
    if (!text) {
        showError('Please enter text to encode');
        return;
    }
    
    try {
        elements.encodeBtn.classList.add('loading');
        
        const response = await fetch('/api/encode', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: text })
        });
        
        const result = await response.json();
        
        if (result.success) {
            elements.encodedOutput.value = result.encoded_text;
            displayEncodingStats(result.statistics);
            showSuccess('Text encoded successfully!');
        } else {
            showError(result.error || 'Encoding failed');
        }
    } catch (error) {
        console.error('Encoding error:', error);
        showError('Network error during encoding');
    } finally {
        elements.encodeBtn.classList.remove('loading');
    }
}

/**
 * Decode text function
 */
async function decodeText() {
    const codes = elements.inputCodes.value.trim();
    
    if (!codes) {
        showError('Please enter codes to decode');
        return;
    }
    
    try {
        elements.decodeBtn.classList.add('loading');
        
        const response = await fetch('/api/decode', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ codes: codes })
        });
        
        const result = await response.json();
        
        if (result.success) {
            elements.decodedOutput.value = result.decoded_text;
            displayDecodingStats(result);
            showSuccess('Codes decoded successfully!');
        } else {
            elements.decodedOutput.value = result.decoded_text || '';
            displayDecodingStats(result);
            if (result.unknown_codes && result.unknown_codes.length > 0) {
                showWarning(`Decoded with ${result.unknown_codes.length} unknown codes`);
            } else {
                showError(result.error || 'Decoding failed');
            }
        }
    } catch (error) {
        console.error('Decoding error:', error);
        showError('Network error during decoding');
    } finally {
        elements.decodeBtn.classList.remove('loading');
    }
}

/**
 * Search dictionary function
 */
async function searchDictionary() {
    const query = elements.dictionarySearch.value.trim();
    
    // Get the search results element
    const searchResultsElement = document.getElementById('searchResults');
    if (!searchResultsElement) return;
    
    if (!query) {
        searchResultsElement.innerHTML = '';
        const container = document.createElement('div');
        container.className = 'text-center text-muted';
        
        const icon = document.createElement('i');
        icon.className = 'fas fa-search fa-3x mb-3';
        
        const message = document.createElement('p');
        message.textContent = 'Search the dictionary or click "Random Entries" to explore';
        
        container.appendChild(icon);
        container.appendChild(message);
        searchResultsElement.appendChild(container);
        return;
    }
    
    try {
        const response = await fetch(`/api/dictionary/search?q=${encodeURIComponent(query)}`);
        const result = await response.json();
        
        if (result.success) {
            displaySearchResults(result.results, result.query);
        } else {
            showError(result.error || 'Search failed');
        }
    } catch (error) {
        console.error('Search error:', error);
        showError('Network error during search');
    }
}

/**
 * Load random dictionary entries
 */
async function loadRandomEntries() {
    try {
        const response = await fetch('/api/dictionary/random?count=20');
        const result = await response.json();
        
        if (result.success) {
            displaySearchResults(result.results, 'Random Entries');
            elements.dictionarySearch.value = '';
        } else {
            showError(result.error || 'Failed to load random entries');
        }
    } catch (error) {
        console.error('Random entries error:', error);
        showError('Network error loading random entries');
    }
}

/**
 * Load dictionary statistics
 */
async function loadDictionaryStats() {
    try {
        const response = await fetch('/api/dictionary/stats');
        const result = await response.json();
        
        if (result.success) {
            dictionaryStats = result;
            displayDictionaryStats(result);
            
            // Update hero stats
            document.getElementById('total-mappings').textContent = result.total_entries;
        } else {
            console.error('Failed to load dictionary stats:', result.error);
        }
    } catch (error) {
        console.error('Dictionary stats error:', error);
    }
}

/**
 * Load examples
 */
async function loadExamples() {
    try {
        const response = await fetch('/api/examples');
        const result = await response.json();
        
        if (result.success) {
            examples = result.examples;
            displayExamples(result.examples);
        } else {
            console.error('Failed to load examples:', result.error);
        }
    } catch (error) {
        console.error('Examples error:', error);
    }
}

/**
 * Display encoding statistics
 */
function displayEncodingStats(stats) {
    elements.encodingStats.style.display = 'block';
    
    document.getElementById('originalLength').textContent = stats.original_length;
    document.getElementById('encodedLength').textContent = stats.encoded_length;
    document.getElementById('compressionRatio').textContent = stats.compression_ratio + 'x';
    document.getElementById('spaceSaved').textContent = stats.percentage_saved + '%';
    
    // Add animation
    elements.encodingStats.classList.add('fade-in');
}

/**
 * Display decoding statistics
 */
function displayDecodingStats(result) {
    elements.decodingStats.style.display = 'block';
    
    document.getElementById('totalCodes').textContent = result.total_codes;
    document.getElementById('recognizedCodes').textContent = result.recognized_codes;
    document.getElementById('recognitionRate').textContent = result.recognition_rate + '%';
    document.getElementById('unknownCodes').textContent = result.unknown_codes.length;
    
    // Show unknown codes if any
    const unknownCodesList = document.getElementById('unknownCodesList');
    const unknownCodesContent = document.getElementById('unknownCodesContent');
    
    if (result.unknown_codes.length > 0) {
        unknownCodesList.style.display = 'block';
        
        // Clear previous content
        unknownCodesContent.innerHTML = '';
        
        // Safely create elements for each unknown code
        result.unknown_codes.forEach((code, index) => {
            const span = document.createElement('span');
            span.className = 'unknown-code';
            span.textContent = code; // Safe text insertion
            unknownCodesContent.appendChild(span);
            
            // Add space between codes (except after the last one)
            if (index < result.unknown_codes.length - 1) {
                unknownCodesContent.appendChild(document.createTextNode(' '));
            }
        });
    } else {
        unknownCodesList.style.display = 'none';
    }
    
    // Add animation
    elements.decodingStats.classList.add('fade-in');
}

/**
 * Display dictionary statistics
 */
function displayDictionaryStats(stats) {
    document.getElementById('dictTotalEntries').textContent = stats.total_entries;
    document.getElementById('dictNumericCodes').textContent = stats.numeric_codes;
    document.getElementById('dictAlphanumericCodes').textContent = stats.alphanumeric_codes;
    document.getElementById('dictFourDigitCodes').textContent = stats.four_digit_codes;
}

/**
 * Safely escape HTML to prevent XSS
 */
function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/**
 * Display search results
 */
function displaySearchResults(results, query) {
    // Get the search results element directly
    const searchResultsElement = document.getElementById('searchResults');
    if (!searchResultsElement) return;
    
    // Clear existing content
    searchResultsElement.innerHTML = '';
    
    if (results.length === 0) {
        // Create no results content safely
        const container = document.createElement('div');
        container.className = 'text-center text-muted';
        
        const icon = document.createElement('i');
        icon.className = 'fas fa-search fa-3x mb-3';
        container.appendChild(icon);
        
        const message = document.createElement('p');
        message.textContent = `No results found for "${query}"`;
        container.appendChild(message);
        
        const button = document.createElement('button');
        button.className = 'btn btn-outline-secondary';
        button.onclick = loadRandomEntries;
        button.innerHTML = '<i class="fas fa-random me-2"></i>Try Random Entries';
        container.appendChild(button);
        
        searchResultsElement.appendChild(container);
        return;
    }
    
    // Create header
    const header = document.createElement('div');
    header.className = 'd-flex justify-content-between align-items-center mb-3';
    
    const title = document.createElement('h5');
    title.className = 'mb-0';
    title.innerHTML = '<i class="fas fa-search me-2"></i>';
    const titleText = document.createTextNode(
        query === 'Random Entries' ? 'Random Entries' : `Search Results for "${escapeHtml(query)}"`
    );
    title.appendChild(titleText);
    
    const badge = document.createElement('span');
    badge.className = 'badge bg-primary';
    badge.textContent = `${results.length} results`;
    
    header.appendChild(title);
    header.appendChild(badge);
    searchResultsElement.appendChild(header);
    
    // Create results container
    const resultsContainer = document.createElement('div');
    resultsContainer.className = 'search-results-container';
    
    results.forEach(result => {
        const resultItem = document.createElement('div');
        resultItem.className = 'search-result-item';
        
        const flexContainer = document.createElement('div');
        flexContainer.className = 'd-flex justify-content-between align-items-start';
        
        // Left content
        const leftContent = document.createElement('div');
        
        const codeBadge = document.createElement('span');
        codeBadge.className = `code-badge ${escapeHtml(result.type)}`;
        codeBadge.textContent = result.code;
        
        const textSpan = document.createElement('span');
        textSpan.className = 'ms-2 text-dark';
        textSpan.textContent = result.text;
        
        leftContent.appendChild(codeBadge);
        leftContent.appendChild(textSpan);
        
        // Right buttons
        const btnGroup = document.createElement('div');
        btnGroup.className = 'btn-group btn-group-sm';
        
        const encodeBtn = document.createElement('button');
        encodeBtn.className = 'btn btn-outline-primary btn-sm';
        encodeBtn.innerHTML = '<i class="fas fa-plus"></i>';
        encodeBtn.onclick = () => useCode(result.code, 'encode');
        
        const decodeBtn = document.createElement('button');
        decodeBtn.className = 'btn btn-outline-info btn-sm';
        decodeBtn.innerHTML = '<i class="fas fa-arrow-down"></i>';
        decodeBtn.onclick = () => useCode(result.code, 'decode');
        
        btnGroup.appendChild(encodeBtn);
        btnGroup.appendChild(decodeBtn);
        
        flexContainer.appendChild(leftContent);
        flexContainer.appendChild(btnGroup);
        resultItem.appendChild(flexContainer);
        resultsContainer.appendChild(resultItem);
    });
    
    searchResultsElement.appendChild(resultsContainer);
}

/**
 * Display examples dropdown
 */
function displayExamples(examples) {
    // Clear existing content
    elements.examplesList.innerHTML = '';
    
    examples.forEach(example => {
        const listItem = document.createElement('li');
        
        const link = document.createElement('a');
        link.className = 'dropdown-item';
        link.href = '#';
        link.onclick = (e) => {
            e.preventDefault();
            useExample(example.text);
        };
        
        const titleDiv = document.createElement('div');
        titleDiv.className = 'fw-bold';
        titleDiv.textContent = example.description;
        
        const textSmall = document.createElement('small');
        textSmall.className = 'text-muted';
        textSmall.textContent = example.text;
        
        link.appendChild(titleDiv);
        link.appendChild(textSmall);
        listItem.appendChild(link);
        elements.examplesList.appendChild(listItem);
    });
}

/**
 * Use example text
 */
function useExample(text) {
    elements.inputText.value = text;
    encodeText();
}

/**
 * Use code in encoder or decoder
 */
function useCode(code, mode) {
    if (mode === 'encode') {
        // Add code to decoder input
        const current = elements.inputCodes.value.trim();
        elements.inputCodes.value = current ? `${current} ${code}` : code;
        scrollToSection('decoder');
    } else {
        // Add text to encoder input (would need to decode first to get text)
        elements.inputCodes.value = code;
        decodeText();
        scrollToSection('decoder');
    }
}

/**
 * Auto-encode on input (debounced)
 */
function autoEncode() {
    const text = elements.inputText.value.trim();
    if (text && text.length > 5) {
        encodeText();
    }
}

/**
 * Auto-decode on input (debounced)
 */
function autoDecode() {
    const codes = elements.inputCodes.value.trim();
    if (codes && codes.length > 2) {
        decodeText();
    }
}

/**
 * Clear input text
 */
function clearInput() {
    elements.inputText.value = '';
    elements.encodedOutput.value = '';
    elements.encodingStats.style.display = 'none';
}

/**
 * Clear input codes
 */
function clearCodes() {
    elements.inputCodes.value = '';
    elements.decodedOutput.value = '';
    elements.decodingStats.style.display = 'none';
}

/**
 * Copy encoded text
 */
function copyEncoded() {
    copyToClipboard(elements.encodedOutput.value, 'Encoded text copied!');
}

/**
 * Copy decoded text
 */
function copyDecoded() {
    copyToClipboard(elements.decodedOutput.value, 'Decoded text copied!');
}

/**
 * Use encoded text as decoder input
 */
function useAsDecoderInput() {
    const encodedText = elements.encodedOutput.value.trim();
    if (encodedText) {
        elements.inputCodes.value = encodedText;
        scrollToSection('decoder');
        decodeText();
    } else {
        showError('No encoded text to use');
    }
}

/**
 * Copy text to clipboard
 */
async function copyToClipboard(text, successMessage) {
    if (!text) {
        showError('Nothing to copy');
        return;
    }
    
    try {
        await navigator.clipboard.writeText(text);
        showCopyFeedback(successMessage);
    } catch (error) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            showCopyFeedback(successMessage);
        } catch (fallbackError) {
            showError('Failed to copy to clipboard');
        }
        
        document.body.removeChild(textArea);
    }
}

/**
 * Show copy feedback
 */
function showCopyFeedback(message) {
    const feedback = document.createElement('div');
    feedback.className = 'copy-feedback';
    
    const icon = document.createElement('i');
    icon.className = 'fas fa-check me-2';
    
    const text = document.createTextNode(message);
    
    feedback.appendChild(icon);
    feedback.appendChild(text);
    document.body.appendChild(feedback);
    
    setTimeout(() => {
        feedback.remove();
    }, 3000);
}

/**
 * Handle keyboard shortcuts
 */
function handleKeyboardShortcuts(e) {
    // Ctrl+Enter to encode/decode
    if (e.ctrlKey && e.key === 'Enter') {
        if (document.activeElement === elements.inputText) {
            encodeText();
        } else if (document.activeElement === elements.inputCodes) {
            decodeText();
        }
    }
    
    // Ctrl+K to focus search
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        elements.dictionarySearch.focus();
        scrollToSection('dictionary');
    }
}

/**
 * Scroll to section
 */
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

/**
 * Set loading state
 */
function setLoading(loading, message = 'Loading...') {
    isLoading = loading;
    
    if (loading) {
        elements.loadingText.textContent = message;
        elements.loadingModal.show();
    } else {
        elements.loadingModal.hide();
    }
}

/**
 * Show success message
 */
function showSuccess(message) {
    showToast(message, 'success');
}

/**
 * Show error message
 */
function showError(message) {
    showToast(message, 'danger');
}

/**
 * Show warning message
 */
function showWarning(message) {
    showToast(message, 'warning');
}

/**
 * Show toast notification
 */
function showToast(message, type = 'info') {
    // Create toast container if it doesn't exist
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'position-fixed top-0 end-0 p-3';
        container.style.zIndex = '1055';
        document.body.appendChild(container);
    }
    
    // Create toast
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    
    const flexDiv = document.createElement('div');
    flexDiv.className = 'd-flex';
    
    const toastBody = document.createElement('div');
    toastBody.className = 'toast-body';
    
    const icon = document.createElement('i');
    icon.className = `fas fa-${getToastIcon(type)} me-2`;
    
    const messageText = document.createTextNode(message);
    
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'btn-close btn-close-white me-2 m-auto';
    closeBtn.setAttribute('data-bs-dismiss', 'toast');
    
    toastBody.appendChild(icon);
    toastBody.appendChild(messageText);
    flexDiv.appendChild(toastBody);
    flexDiv.appendChild(closeBtn);
    toast.appendChild(flexDiv);
    
    container.appendChild(toast);
    
    // Show toast
    const bsToast = new bootstrap.Toast(toast, { delay: 5000 });
    bsToast.show();
    
    // Remove toast after it's hidden
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}

/**
 * Get icon for toast type
 */
function getToastIcon(type) {
    switch (type) {
        case 'success': return 'check-circle';
        case 'danger': return 'exclamation-circle';
        case 'warning': return 'exclamation-triangle';
        default: return 'info-circle';
    }
}

/**
 * Debounce function
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Initialize smooth scrolling for navigation
 */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const href = this.getAttribute('href');
        if (!href || href === '#') return; // Skip empty or just '#' hrefs
        const target = document.querySelector(href);
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Export functions for global access
window.scrollToSection = scrollToSection;
window.useExample = useExample;
window.useCode = useCode;
window.loadRandomEntries = loadRandomEntries;
